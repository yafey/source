package com.java1234.user.service;

import com.java1234.user.entity.User;

/**
 * 用户Service接口
 * @author Administrator
 *
 */
public interface UserService {

	public User login(User user);
}
